﻿namespace TrainAppSample
{
    internal class Names
    {
    }
}