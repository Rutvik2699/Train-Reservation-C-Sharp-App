﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainAppSample
{
    public class Seat 
    {

        public int SeatID { get; set; }

        public string PassengerName{ get; set; }

    }
   
}
