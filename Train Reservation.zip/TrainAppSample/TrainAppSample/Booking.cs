﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainAppSample
{
    public class Booking
    {

        public string firstName { get; set; }

        public string seatName { get; set; }

        public List<Seat> NumberOfSeats { get; set; }
    }
}
