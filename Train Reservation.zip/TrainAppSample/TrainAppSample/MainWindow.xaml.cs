﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TrainAppSample
{
    
    /// Interaction logic for MainWindow.xaml
    public partial class MainWindow : Window
    {
        //static Seat seat1 = new Seat("1");

        static List<int> ListOfSeats = new List<int>();
        //List of Seat Buttons
        static List<Button> SeatButtons = new List<Button>();

        static List<Seat> passengersList = new List<Seat>();


        int  allocatedSeat = -1;
       // string allocatedName = null;
        public MainWindow()
        {
            InitializeComponent();
        } 

		private void SeatClickEventHandler(object sender, RoutedEventArgs e)
		{
            //Book Seat from all above seats
            assignDetails(sender as Button);
            
		}

        //Function for clicking on Seat
        public void assignDetails(Button Seat)
		{

            allocatedSeat = int.Parse(Seat.Content.ToString());
            //  ListOfSeats.allocatedName = NameTextBox.Text;
            ///// allocatedName = NameTextBox.Text;

            //Reserving / Disabling the button when user reserves it
            if (ListOfSeats.Contains(allocatedSeat))
            {
                ListOfSeats.Remove(allocatedSeat);
                SeatButtons.Remove(Seat);
                Seat.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            }
            else
            {
                //Code to shopw error message if all seats are booked
                string SeatFullMessage = "All seats have been booked";
                if (ListOfSeats.Count == 24)
                {
                    MessageBox.Show(SeatFullMessage, "Succcess", MessageBoxButton.OK);
                    return;
                }
                else
                if (ListOfSeats.Count > 0)
                {
                    if ((SeatButtons[SeatButtons.Count - 1].Background as SolidColorBrush).Color == Colors.Red)
                    {
                        //Do Nothing.
                    }
                    else
                    {
                        SeatButtons[SeatButtons.Count - 1].Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
                        SeatButtons.Remove(SeatButtons[SeatButtons.Count - 1]);
                        ListOfSeats.Remove(ListOfSeats[ListOfSeats.Count - 1]);
                    }
                }

                ListOfSeats.Add(allocatedSeat);
                SeatButtons.Add(Seat);
                //Name.Add(allocatedName);
                Seat.Background = new SolidColorBrush(Colors.Green);




                Seat selectedSeat = new Seat();
                selectedSeat.SeatID = allocatedSeat;
                selectedSeat.PassengerName = NameTextBox.Text;
                passengersList.Add(selectedSeat);


              /*  Seat selectedSeat1 = new Seat()
                {
                    SeatID = allocatedSeat,
                    PassengerName = NameTextBox.Text,
                };
              */

                //string strResultJson = JsonConvert.SerializeObject(selectedSeat1);

                //     MessageBox.dkfssajfgbjsndfb

            }
		}

       

		private void GetSeatNumberToDelete(object sender, TextChangedEventArgs e)
		{
           //Do Nothing
		}

        
        /// Book the seat after Submit button is clicked.
        //Button to reserve seat
		private void SubmitButtonHandler(object sender, RoutedEventArgs e)
		{
            int flag = 0;
            for(int i = 0; i < SeatButtons.Count; i++)
			{
                flag = 0;
                if((SeatButtons[i].Background as SolidColorBrush).Color == Colors.Green)
				{
                    SeatButtons[i].Background = new SolidColorBrush(Colors.Red);
                    SeatButtons[i].IsEnabled = false;
                    flag = 1;
                    break;
				}
			}

		    if (flag == 1)
		    {

                string SuccessMessage = "";
                if("" != NameTextBox.Text && null != NameTextBox.Text)
				{

                    
                    //To show the message to the user
                    SuccessMessage = "Seat " + allocatedSeat + " booked successfully for user " + NameTextBox.Text + "!";
                    

                }
				else
				{
                    SuccessMessage = "Seat " + allocatedSeat + " booked successfully!";
                    
                }
                //For new window pop up for success
                MessageBox.Show(SuccessMessage, "Succcess", MessageBoxButton.OK);
                NameTextBox.Text = "";
            }
	    }

        /// Delete booked seat from List object
       
        private void DeleteButtonHandler(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(DeleteSeat.Text))
            {
                foreach (var passenger in passengersList) {
                    if (passenger.SeatID.ToString().Equals(DeleteSeat.Text.Trim()) ||
                        passenger.PassengerName.ToString().Equals(DeleteSeat.Text.Trim())) {
                        enableSeat(passenger.SeatID, true);
                        passengersList.Remove(passenger);

                        string DeleteMessage = "The seat " + passenger.SeatID + "\n Booked by - " + passenger.PassengerName + " is deleted successfully!";
                        MessageBox.Show(DeleteMessage, "Success", MessageBoxButton.OK);

                        return;
                    }
                }

                MessageBox.Show("The seat whose booking you want to delete isn't booked!", "Error!", MessageBoxButton.OK);

            }
        }

        //Function to enable seat
        private void enableSeat(int seatID,bool isNeedToEnable)
        {
            string id = "Seat" + seatID;
            Button st = (Button)this.FindName(id);

            if (isNeedToEnable)
            {
                st.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
                st.IsEnabled = true;
            }
            else {
                st.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
                st.IsEnabled = false;
            }
            
           
        }


       
        //Button to close the window
        private void CloseButtonHandler(object sender, RoutedEventArgs e)
		{
            this.Close();
		}

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            ListOfSeats.Clear();
            passengersList.Clear();

            for (int i = 1; i <= 24; i++) {
                enableSeat(i, true);
            }
        }

        //Button to Save data to JSON file
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if(passengersList == null || passengersList.Count == 0)
            {
                MessageBox.Show("Please Book a seat to save seating plan", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            string passengerData = JsonConvert.SerializeObject(passengersList);
            saveJsonToFile(passengerData);
        }
        //Function to save data to JSON file
        private void saveJsonToFile(string passengerData)
        {
            try
            {
                File.WriteAllText("passengerData.json", passengerData);
                MessageBox.Show("Passenger Data saved successfully to the file","Alert",MessageBoxButton.OK,MessageBoxImage.Information);
            }catch(Exception e)
            {
                MessageBox.Show("Failed TO save passengers Data" + e.Message, "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        ///Load File into Program
                public void Load_Click(object sender, RoutedEventArgs e)
                {

                    try
                    {
                        if (!File.Exists("passengerData.json"))
                        {
                            MessageBox.Show("Passengers Data File Not Available", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                            return;
                        }

                        string passengersInfoText = File.ReadAllText("passengerData.json");

                        List<Seat> dataList = JsonConvert.DeserializeObject<List<Seat>>(passengersInfoText);

                        if (dataList == null || dataList.Count == 0)
                        {
                            MessageBox.Show("Passengers Data Not Available in Passengers Data File", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                            return;
                        }

                        if (dataList.Count != 0)
                        {
                            ListOfSeats.Clear();
                            passengersList.Clear();

                            foreach (var passengerObject in dataList)
                            {
                                passengersList.Add(passengerObject);
                                ListOfSeats.Add(passengerObject.SeatID);
                                enableSeat(passengerObject.SeatID, false);
                    }
                        }

                        MessageBox.Show("Passengers Info File Loaded Successfully", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    catch (Exception f)
                    {
                        MessageBox.Show("Faild to Load Passengers Info File - " + f.Message, "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
        }
    }
}
